# Ticketing and Booking System – Project Report

## 1. Introduction
The Ticketing and Booking System is a workflow-based application developed using Pega Platform. It manages movie ticket booking activities through an organized automated process.

## 2. Problem Statement
Manual ticket booking can involve separate activities such as checking movie details, theatre availability, show schedules, seat availability, pricing and confirmation. This project provides a centralized workflow for these activities.

## 3. Proposed Solution
The Pega application uses case management and workflow automation. Important activities are represented as case types and workflow steps so that the booking process can be tracked from submission to final confirmation.

## 4. Major Modules
- **Movie Setup:** Maintains movie information.
- **Theatre Onboarding:** Captures theatre details.
- **Show Scheduling:** Manages show schedules.
- **Pricing Management:** Configures ticket prices and offers.
- **Seat Allocation:** Manages seating and availability.
- **Movie Ticket Booking:** Captures booking information and completes confirmation.

## 5. Workflow
1. Submit Booking
2. Check Availability
3. Calculate Confirmation
4. Staff Review
5. Booking Confirmed

## 6. Data Model
Important data objects include Movie, Venue, Ticket, Attendee, Schedule and Sponsor.

## 7. Benefits
- Reduces manual processing.
- Provides structured workflow.
- Improves process visibility.
- Makes case status easy to track.
- Supports workflow automation.
- Can be extended with integrations.

## 8. Technology
Pega Platform / Pega Infinity and Pega Blueprint.

## 9. Conclusion
The project demonstrates how Pega can be used to build a workflow-driven application for movie ticket booking. It provides a foundation for payment integration, real-time seat management, notifications and analytics.
