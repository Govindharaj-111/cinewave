# User / Demo Guide

## Before the Demo
Log in to the authorized Pega environment and open the Ticketing and Booking application.

## Demo Steps
1. Open **Movie Ticket Booking**.
2. Create a new booking case.
3. Enter attendee name, event/movie, ticket quantity and payment method.
4. Submit the booking.
5. Complete **Check Availability**.
6. Proceed through the confirmation workflow.
7. Complete **Staff Review** when assigned.
8. Verify the final status: **Booking Confirmed**.

## Security
Never upload Pega passwords, access codes, private tokens or other sensitive information to GitHub.
