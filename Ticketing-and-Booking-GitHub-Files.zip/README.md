# 🎬 Ticketing and Booking System

A workflow-based **Movie Ticketing and Booking System** developed using **Pega Platform / Pega Infinity**.

## 📌 Project Overview
This application simplifies movie ticket booking through structured workflows for movie setup, theatre onboarding, show scheduling, ticket pricing, seat allocation, and booking confirmation.

## 🎯 Objectives
- Simplify movie ticket booking.
- Manage movie and theatre information.
- Configure show schedules and ticket pricing.
- Manage seat availability and allocation.
- Capture attendee booking details.
- Provide workflow-based booking confirmation.

## 🛠️ Technology Used
- Pega Platform / Pega Infinity
- Pega Blueprint
- Case Management
- Workflow Automation
- Data Objects
- Personas and Channels

## 🧩 Main Case Types
1. Movie Setup
2. Movie Ticket Booking
3. Pricing Management
4. Seat Allocation
5. Show Scheduling
6. Theatre Onboarding

## 🔄 Movie Ticket Booking Workflow
**Submit Booking → Check Availability → Calculate Confirmation → Staff Review → Booking Confirmed**

The booking process can capture:
- Attendee
- Event/Movie Name
- Ticket Quantity
- Ticket Price
- Payment Method
- Discount Code
- Confirmation Number
- Venue Capacity

## 👥 Personas
- Attendee
- Ticketing Manager
- Event Planner
- Vendor
- Sponsor

## 📊 Data Objects
- Movie
- Venue
- Ticket
- Attendee
- Schedule
- Sponsor

## 🏗️ Blueprint Information
**Blueprint ID:** BP-2417105  
**Application:** Ticketing and Booking  
**Industry:** Consumer Services  
**Subsegment:** Entertainment

## ▶️ How to Demonstrate
1. Log in to the authorized Pega environment.
2. Open the **Ticketing and Booking** application.
3. Select **Movie Ticket Booking**.
4. Create a new booking case.
5. Enter attendee, movie/event, ticket quantity and payment details.
6. Submit the booking.
7. Complete availability and confirmation stages.
8. Complete staff review.
9. Verify **Booking Confirmed**.

> Pega login credentials, access codes and private tokens are intentionally not included.

## 🚀 Future Enhancements
- Online payment gateway
- Email/SMS notifications
- Real-time seat availability
- QR-code ticket generation
- Booking history
- Analytics dashboard

## 👨‍💻 Author
**Govindharaj**

## 📄 Academic Project
This repository is maintained for academic project submission and demonstration.
